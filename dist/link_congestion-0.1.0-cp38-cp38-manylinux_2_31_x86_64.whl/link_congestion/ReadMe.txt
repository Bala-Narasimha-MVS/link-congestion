0)pip3 install -r requirements.txt 
1)Change details in config.ini
2) Write a cronjob to run "python3 link_tp_main.py config.ini" every N minutes as required. (Full paths needed while writing cronjob.)

NOTE : CRETAE Linker.csv using Helpers code.