0) pip3 install -r requirements.txt
1) Change the linker.ini file accordingly.
2) Run "python3 linker_main.py linker.ini" from Helpers folder to create Linker.csv
